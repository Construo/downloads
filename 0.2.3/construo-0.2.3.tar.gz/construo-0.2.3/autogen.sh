#!/bin/sh

aclocal-1.7
automake-1.7 --add-missing --force --copy
autoconf
autoheader

# EOF #
